# Charte graphique F.A.T. — règles d'intégration (pour Codex)

Référence visuelle : `Identité F.A.T.dc.html` (tour 2 = pages validées, tour 1 = fondations).
Principe directeur : **l'olive habille, l'acide mesure.** Les verts mats structurent le décor ;
le vert acide et la famille de courbes sont réservés aux données calculées et aux CTA principaux.

## 1. Tokens — à coller dans le bloc `:root` de `assets/site.css`

```css
:root {
  /* Thème nuit (défaut) */
  --ink-0: #10140c;        /* fond page */
  --ink-1: #171c11;        /* panneaux */
  --ink-2: #222b18;        /* surfaces actives, chips */
  --ink-3: #12160d;        /* fond scène graphe */
  --line: #2a3322;
  --line-strong: #3a4529;
  --olive: #4a5537;        /* patchs, bordures stencil */
  --ranger: #6b7a4f;       /* grilles 3D, lignes de visée */
  --khaki: #b5b09a;
  --paper: #e9ecdd;        /* texte principal */
  --muted: #8b9378;
  --muted-strong: #c9cdb4;
  --muted-dim: #77805e;
  --acid: #a8ff3f;         /* LA donnée active + CTA */
  --acid-strong: #7ee900;
  --curve-2: #5fd4a8;      /* comparaison 2 */
  --curve-3: #d4b95f;      /* comparaison 3 / tag ESTIMÉ */
  --curve-4: #e07856;      /* impact, max, danger doux */
  --danger: #ff6b6b;
  --shadow: 0 24px 60px rgb(0 0 0 / 40%);
  --radius-sm: .5rem; --radius: .8rem; --radius-lg: 1rem;
  --content: 80rem; --reading: 46rem;
  --font: Inter, ui-sans-serif, system-ui, sans-serif;
  --font-display: Saira, var(--font);           /* titres + gros chiffres */
  --font-mono: "IBM Plex Mono", ui-monospace, monospace; /* données, labels */
  --font-stencil: "Saira Stencil One", var(--font-display); /* marquage seul */
}
@media (prefers-color-scheme: light) {
  :root {
    --ink-0: #eef0e2; --ink-1: #ffffff; --ink-2: #e0e3cf; --ink-3: #f6f7ec;
    --line: #d5d8c2; --line-strong: #cfd2bd;
    --paper: #171c11; --muted: #5a6247; --muted-strong: #333a28; --muted-dim: #77805e;
    --acid-text: #5c8a00;  /* texte accent AA — l'acide pur reste réservé aux aplats */
    --accent-deep: #3d5220;
    --shadow: 0 18px 44px rgb(23 28 17 / 12%);
  }
}
```

Polices : Saira (400/600/700/800/900), Saira Stencil One (400), IBM Plex Mono (400/500/600)
à auto-héberger dans `assets/fonts/` comme Inter (pas de CDN, règle PWA). Sous-ensembles latin suffisent.

## 2. Typographie

- **H1/H2/H3** : Saira 800–900, MAJUSCULES sur les pages outil/accueil, letter-spacing -0.015em.
  H1 clamp(2.2rem, 6vw, 3.4rem). Mise en avant : un segment du H1 en `--acid` (nuit) / `--accent-deep` (jour).
- **Corps** : Inter 400, 1rem/1.65. Largeur lecture 65–70 ch (`--reading`).
- **Données & labels UI** : Plex Mono 500–600, MAJUSCULES, letter-spacing .1–.16em, tailles 9–12px.
  Tout chiffre calculé est en Plex Mono ou Saira (métriques héros).
- **Stencil** : uniquement pour le "marquage" — eyebrows, numéros de cartes (01 / ÉNERGIE),
  patchs, badge OPÉRATEUR. Jamais en paragraphe, jamais en dessous de 10px.

## 3. Logo (option 1a validée)

- Bille + courbe ATP + sol pointillé. Source à redessiner dans `assets/img/icon.svg` :
  courbe `--acid`, bille `--paper`, sol `--line-strong` en pointillés.
- Favicon / maskable : tuile `--acid` arrondie, courbe + bille en `--ink-0` (voir 1a, tuile bas-droite).
- Version jour : courbe `#3d5220`, bille `--ink-0`.
- Lockup header : icône 28–30px + « F.A.T. » Saira 900 (point final acide) + sous-titre mono letterspacé.

## 4. Composants clés

- **Chip/tag mono** : Plex Mono 9–10px maj, radius 99px. Variantes : plein acide (actif/CTA),
  bordé `--line-strong` (neutre), bordé couleur de courbe (légende comparaison).
- **Tags de confiance** (obligatoires sur toute valeur) : MESURÉ (fond acide), INTERPOLÉ (`--curve-2`),
  ESTIMÉ (`--curve-3`), EXTRAPOLÉ / DÉCLARÉ (`--curve-4` ou khaki). Cohérent partout.
- **Carte champ** (formulaire) : panneau `--ink-1`, bordure `--line`, label mono muted,
  valeur Plex Mono 15–17px. Champ "clé" du contexte : bordure `--acid`. Hit target ≥ 44px mobile.
- **Métrique héros** (portée utile) : dégradé 160° `--ink-2`→`--ink-1`, bordure `--acid`, chiffre Saira 800.
- **Patch stencil** (eyebrow) : bordure 1px dashed `--olive`, radius 6px, texte stencil letterspacé.
- **Bande camo** (séparateur, header de carte joueur, strip de réassurance) — gradient CSS pur :
  `linear-gradient(135deg,#2c3520 0 14%,#4a5537 14% 26%,#222b18 26% 47%,#5d6845 47% 58%,#2c3520 58% 79%,#3a4529 79% 100%)`
  Jamais d'image camo, jamais derrière du texte sans voile `rgb(16 20 12 / .8)`.
- **Hachures danger** : `repeating-linear-gradient(45deg, var(--acid) 0 14px, var(--ink-1) 14px 28px)`
  pour hors-enveloppe / limites d'énergie.

## 5. Le graphe de trajectoire (cœur du produit)

- **Deux modes, un seul état** : PROFIL 2D et VUE DRONE 3D partagent paramètres et résultats.
  Toggle en haut à gauche de la scène. Les onglets de donnée (TRAJECTOIRE / ÉNERGIE / DÉRIVE / ROTATION)
  restent à droite et s'appliquent au mode 2D.
- **2D** : format panoramique ≈4,5:1 desktop, 3:1 mobile. Exagération verticale ×10 TOUJOURS affichée
  (chip "HAUTEUR ×10"). Bande enveloppe ATP ±15,24 cm en `--acid` à 7–8% d'opacité, ligne de visée
  `--ranger` pointillée, grille `#1d2415`, sol `--line-strong` 2px. Marqueurs : portée utile (point acide
  + label), impact (`--curve-4`). Courbe active 3.5px `--acid`, comparaisons 2px pointillées.
- **3D (three.js, module lazy-loadé)** : sol quadrillé `--ranger` ~26% sur `--ink-3`, ligne de tir,
  ruban trajectoire `--acid`, **ombre au sol** = projection de la dérive (pointillés `--ranger`),
  marqueurs DÉPART/APEX/IMPACT en sprites mono. Caméras préréglées : DRONE / TIREUR / PROFIL
  (PROFIL = même cadrage que le 2D). Bouton ▶ REJOUER LE TIR anime la bille sur la courbe.
  Pas de WebGL → le toggle 3D n'apparaît pas (progressive enhancement, aucun message d'erreur).
- **Sticky** : desktop, la scène reste épinglée en haut du viewport pendant qu'on édite les champs
  dessous. Mobile : scène 2D compacte + 4 chips métriques épinglées sous le header ; la 3D s'ouvre
  exclusivement en plein écran paysage (orbite tactile, double-tap recadre).
- `prefers-reduced-motion` : pas d'animation de tir automatique, transitions caméra instantanées.

## 6. Pages (maquettes de référence)

- **Accueil 2a** : hero copy + console 1,50 J → strip camo réassurance → cockpit calculateur
  (scène / paramètres 46% / résultats) → cartes guides numérotées stencil → footer 3 colonnes + devise mono.
- **Mobile 2b** : graphe + chips épinglés, presets scrollables, champs 2 colonnes, CTA pleine largeur.
- **Joueurs 2c** (`/tu-joues-avec-quoi/`) : cartes opérateur — bandeau camo + n° stencil,
  photo 4:3, 4 stats (BILLE/ÉNERGIE/MESURE/RÉPLIQUE), citation italique, CTA acide
  « VOIR SA TRAJECTOIRE → » = lien simulateur avec les params URL existants (m/j/h…). Badge CHRONY ✓
  vs DÉCLARÉ. Dernière carte = recrutement (bordure dashed).
- **Guide 2d** : colonne lecture + rail sticky (sommaire, carte CTA banc fond `--ink-1` + liseré camo,
  rappel THÉORIQUE ≠ MESURÉ). Callouts avec tag de confiance. Le guide montre le thème jour.
- **Outil 2e** : sélecteurs à gauche, gros résultat + tag de confiance + courbe à droite.
  Template de tous les futurs outils SEO.
- **À propos 2f** : photo + patch KEEP, bloc ATTRIBUTION Mackila réutilisable.

## 7. Interdits

- Pas d'acide en grande surface de fond ; jamais de texte acide sur clair (utiliser `--acid-text`).
- Pas d'image/texture camo bitmap ; gradients CSS uniquement.
- Stencil jamais en corps de texte. Emoji : non. Icônes : traits simples ou caractères mono (▸ ● ⛶ ▶).
- Une valeur affichée sans tag de confiance (MESURÉ/INTERPOLÉ/ESTIMÉ/…) est un bug.
- Ne pas casser : accessibilité clavier, contrastes AA, `prefers-reduced-motion`,
  URLs partageables, fonctionnement hors ligne (fonts et three.js auto-hébergés, `CACHE` incrémenté).
