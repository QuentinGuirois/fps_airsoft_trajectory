import { sightModel } from './physics-core.js';

const MODES = Object.freeze({
  trajectory: Object.freeze({
    unit: 'm',
    axisLabel: 'Hauteur au-dessus du sol',
    referenceLabel: 'La ligne pointillée représente le sol.',
    floorAtZero: true,
    showZeroLine: true,
    value: (point) => point.y,
  }),
  sight: Object.freeze({
    unit: 'cm',
    axisLabel: 'Écart à la visée',
    referenceLabel: 'La ligne pointillée représente la visée ; une valeur négative est sous la visée.',
    floorAtZero: false,
    showZeroLine: true,
    value: (point, context) => (point.y - context.sight.yAt(point.x)) * 100,
  }),
  energy: Object.freeze({
    unit: 'J',
    axisLabel: 'Énergie résiduelle',
    referenceLabel: '',
    floorAtZero: true,
    showZeroLine: false,
    value: (point) => point.energyJ,
  }),
  drift: Object.freeze({
    unit: 'cm',
    axisLabel: 'Dérive latérale',
    referenceLabel: 'La ligne pointillée représente une dérive nulle.',
    floorAtZero: false,
    showZeroLine: true,
    value: (point) => point.z * 100,
  }),
  spin: Object.freeze({
    unit: 'tr/min',
    axisLabel: 'Rotation',
    referenceLabel: '',
    floorAtZero: true,
    showZeroLine: false,
    value: (point) => point.rpm,
  }),
});

export function chartMode(mode) {
  return MODES[mode] || MODES.trajectory;
}

export function buildChartValues(simulation, mode = 'trajectory') {
  const selected = chartMode(mode);
  const context = mode === 'sight' ? { sight: sightModel(simulation) } : {};
  return {
    ...selected,
    values: simulation.points.map((point) => ({
      x: point.x,
      y: selected.value(point, context),
    })),
  };
}

export function chartYDomain(series) {
  const values = series
    .flatMap((item) => item.values)
    .map((point) => point.y)
    .filter(Number.isFinite);
  const floorAtZero = series[0]?.floorAtZero ?? false;

  if (!values.length) return { minY: 0, maxY: 1 };

  if (floorAtZero) {
    const rawMax = Math.max(0, ...values);
    const maxY = rawMax > 0 ? rawMax * 1.1 : 1;
    return { minY: 0, maxY };
  }

  let minY = Math.min(0, ...values);
  let maxY = Math.max(0, ...values);
  if (Math.abs(maxY - minY) < 0.01) {
    minY -= 1;
    maxY += 1;
  }
  const padding = (maxY - minY) * 0.1;
  return { minY: minY - padding, maxY: maxY + padding };
}
