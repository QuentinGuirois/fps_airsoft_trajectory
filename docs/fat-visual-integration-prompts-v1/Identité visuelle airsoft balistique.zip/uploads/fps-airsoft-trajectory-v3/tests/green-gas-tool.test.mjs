import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  pointForTemperature,
  productsForBrand,
  psiToBar,
  resolveSelection,
} from '../gas-pressure-tool.js';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const data = JSON.parse(await readFile(join(root, 'data', 'green-gas-pressure-curves.json'), 'utf8'));

test('le jeu green gas est valide et ses identifiants sont uniques', () => {
  assert.equal(data.schemaVersion, '1.0.0');
  assert.equal(data.products.length, 32);
  assert.equal(data.brands.length, 10);
  assert.equal(new Set(data.products.map(({ id }) => id)).size, data.products.length);
  assert.equal(new Set(data.sources.map(({ id }) => id)).size, data.sources.length);
  assert.ok(data.excludedCandidates.length > 0);
});

test('chaque produit fournit 56 températures entières de −15 à 40 °C par pas exact de 1 °C', () => {
  for (const product of data.products) {
    assert.equal(product.curve.length, 56, product.id);
    assert.deepEqual(
      product.curve.map(({ temperatureC }) => temperatureC),
      Array.from({ length: 56 }, (_, index) => index - 15),
      product.id,
    );
  }
});

test('chaque ancre fabricant reste exactement présente dans la courbe applicative', () => {
  for (const product of data.products) {
    const point = pointForTemperature(product, product.referenceTemperatureC);
    assert.ok(point, product.id);
    assert.equal(point.estimatedPsi, product.referencePsi, product.id);
  }
});

test('les 18 points de mesure ASG sont conservés exactement', () => {
  const asgProducts = productsForBrand(data, 'ASG Ultrair');
  assert.equal(asgProducts.length, 3);
  assert.equal(asgProducts.reduce((sum, product) => sum + product.measuredPoints.length, 0), 18);
  for (const product of asgProducts) {
    for (const measured of product.measuredPoints) {
      assert.equal(pointForTemperature(product, measured.temperatureC).estimatedPsi, measured.psi, `${product.id} à ${measured.temperatureC} °C`);
    }
  }
});

test('toutes les courbes sont monotones croissantes', () => {
  for (const product of data.products) {
    for (let index = 1; index < product.curve.length; index += 1) {
      assert.ok(product.curve[index].estimatedPsi >= product.curve[index - 1].estimatedPsi, `${product.id} index ${index}`);
    }
  }
});

test('la conversion PSI vers bar utilise la constante imposée', () => {
  assert.equal(psiToBar(14.5037738), 1);
  assert.ok(Math.abs(psiToBar(145) - 9.997398056497545) < 1e-12);
});

test('le filtrage marque vers modèles ne retourne que les produits publiables de la marque', () => {
  const nimrod = productsForBrand(data, 'Nimrod Tactical');
  assert.equal(nimrod.length, 4);
  assert.ok(nimrod.every(({ brand }) => brand === 'Nimrod Tactical'));
  assert.ok(nimrod.every(({ id }) => !data.excludedCandidates.some((candidate) => candidate.id === id)));
});

test('les paramètres URL restaurent la température, la marque et le gaz avant localStorage', () => {
  const restored = resolveSelection(
    data,
    '?t=12&brand=Nimrod%20Tactical&gas=nimrod-green-145',
    { t: 30, brand: 'Abbey', gas: 'abbey-predator-144a' },
  );
  assert.deepEqual(restored, {
    temperatureC: 12,
    brand: 'Nimrod Tactical',
    gas: 'nimrod-green-145',
  });
});

test('les sélections locales servent de repli quand l’URL est vide', () => {
  const restored = resolveSelection(data, '', { t: 7, brand: 'Abbey', gas: 'abbey-predator-144a' });
  assert.deepEqual(restored, { temperatureC: 7, brand: 'Abbey', gas: 'abbey-predator-144a' });
});

test('la page gaz expose son SEO, ses données structurées et son interface accessible', async () => {
  const html = await readFile(join(root, 'outils', 'choisir-gaz-airsoft-pression-temperature', 'index.html'), 'utf8');
  assert.match(html, /<h1[^>]*>[^<]*quel gaz airsoft choisir selon la température/i);
  assert.match(html, /<title>[^<]+<\/title>/);
  assert.match(html, /<meta name="description"/);
  assert.match(html, /<link rel="canonical" href="https:\/\/fps-airsoft-trajectory\.com\/outils\/choisir-gaz-airsoft-pression-temperature\/">/);
  assert.match(html, /"@type":"SoftwareApplication"/);
  assert.match(html, /"@type":"FAQPage"/);
  assert.match(html, /"@type":"BreadcrumbList"/);
  assert.match(html, /aria-live="polite"/);
  assert.match(html, /id="gas-temperature"[^>]*step="1"/);
  assert.match(html, /id="gas-temperature-range"[^>]*step="1"/);
});

test('le service worker met en cache l’outil et sa donnée pour le mode hors ligne', async () => {
  const worker = await readFile(join(root, 'service-worker.js'), 'utf8');
  assert.match(worker, /\/outils\/choisir-gaz-airsoft-pression-temperature\//);
  assert.match(worker, /\/data\/green-gas-pressure-curves\.json/);
  assert.match(worker, /\/gas-pressure-tool\.js/);
  assert.match(worker, /\/gas-pressure-app\.js/);
  assert.match(worker, /caches\.match\(url\.pathname\)/);
});
