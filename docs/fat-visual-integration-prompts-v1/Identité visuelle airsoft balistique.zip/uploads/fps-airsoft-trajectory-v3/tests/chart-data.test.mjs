import test from 'node:test';
import assert from 'node:assert/strict';
import { buildChartValues, chartYDomain } from '../chart-data.js';
import { pointAtDistance, simulateTrajectory } from '../physics-core.js';

test('la vue trajectoire affiche une hauteur au-dessus du sol sans domaine négatif', () => {
  const simulation = simulateTrajectory();
  const series = buildChartValues(simulation, 'trajectory');
  const domain = chartYDomain([series]);

  assert.equal(series.unit, 'm');
  assert.ok(series.values.every((point) => point.y >= 0));
  assert.equal(domain.minY, 0);
  assert.ok(domain.maxY > Math.max(...series.values.map((point) => point.y)));
});

test('la vue écart visée conserve les valeurs signées utiles au zérotage', () => {
  const simulation = simulateTrajectory({ zeroDistanceM: 35, hopPercent: 0 });
  const series = buildChartValues(simulation, 'sight');
  const muzzle = series.values[0];
  const zeroPoint = pointAtDistance(series.values, 35);

  assert.equal(series.unit, 'cm');
  assert.ok(muzzle.y < 0, 'la bouche est sous la ligne de visée à cause de la hauteur d’optique');
  assert.ok(zeroPoint);
  assert.ok(Math.abs(zeroPoint.y) < 2, 'la trajectoire doit croiser la visée près du zéro demandé');
});

test('les vues énergie et rotation sont cadrées à partir de zéro', () => {
  const simulation = simulateTrajectory();
  for (const mode of ['energy', 'spin']) {
    const series = buildChartValues(simulation, mode);
    assert.equal(chartYDomain([series]).minY, 0);
  }
});
