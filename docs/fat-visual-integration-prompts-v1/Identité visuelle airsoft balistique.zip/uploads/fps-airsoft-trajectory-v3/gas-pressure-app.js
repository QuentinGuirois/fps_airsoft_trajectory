import {
  fullProductName,
  normalizeTemperature,
  pointPresentation,
  productsForBrand,
  resolveSelection,
  resultForSelection,
  selectionSearchParams,
} from './gas-pressure-tool.js';

const DATA_URL = '/data/green-gas-pressure-curves.json';
const STORAGE_KEY = 'fat-green-gas-selection-v1';
const REQUIRED_DISCLAIMER = 'La pression affichée est une estimation théorique calculée à partir des valeurs publiées par les fabricants ou distributeurs. Elle ne garantit ni la pression réelle dans un chargeur, ni la compatibilité avec une réplique, ni la puissance obtenue.';

const elements = {
  form: document.querySelector('[data-gas-form]'),
  temperature: document.querySelector('#gas-temperature'),
  temperatureRange: document.querySelector('#gas-temperature-range'),
  temperatureOutput: document.querySelector('#gas-temperature-output'),
  brand: document.querySelector('#gas-brand'),
  product: document.querySelector('#gas-product'),
  status: document.querySelector('#gas-tool-status'),
  result: document.querySelector('#gas-result'),
  psi: document.querySelector('#gas-result-psi'),
  bar: document.querySelector('#gas-result-bar'),
  name: document.querySelector('#gas-result-name'),
  commercial: document.querySelector('#gas-result-commercial'),
  reference: document.querySelector('#gas-result-reference'),
  precise: document.querySelector('#gas-result-precise'),
  kind: document.querySelector('#gas-result-kind'),
  kindPill: document.querySelector('#gas-result-kind-pill'),
  rangeWarning: document.querySelector('#gas-range-warning'),
  extrapolationWarning: document.querySelector('#gas-extrapolation-warning'),
  notes: document.querySelector('#gas-result-notes'),
  sources: document.querySelector('#gas-result-sources'),
  collectionDate: document.querySelector('#gas-result-date'),
  copy: document.querySelector('#gas-copy'),
  share: document.querySelector('#gas-share'),
  feedback: document.querySelector('#gas-share-feedback'),
  compare: document.querySelector('#gas-compare'),
  compareResult: document.querySelector('#gas-compare-result'),
};

const numberFormat = new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const preciseFormat = new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const dateFormat = new Intl.DateTimeFormat('fr-FR', { dateStyle: 'long', timeZone: 'UTC' });

let data = null;
let state = null;
let currentResult = null;

function readStoredSelection() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
  } catch {
    return {};
  }
}

function saveSelection() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      t: state.temperatureC,
      brand: state.brand,
      gas: state.gas,
    }));
  } catch {
    // Le résultat reste utilisable lorsque le stockage privé est indisponible.
  }
}

function updateUrl() {
  const params = selectionSearchParams(state);
  history.replaceState(null, '', `${location.pathname}?${params.toString()}${location.hash}`);
}

function fillSelect(select, options, selectedValue) {
  select.replaceChildren();
  for (const { value, label } of options) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = label;
    option.selected = value === selectedValue;
    select.append(option);
  }
}

function populateBrands() {
  fillSelect(
    elements.brand,
    data.brands.map(({ brand }) => ({ value: brand, label: brand })),
    state.brand,
  );
}

function populateProducts(preferredId = state.gas) {
  const products = productsForBrand(data, state.brand);
  const selected = products.some(({ id }) => id === preferredId) ? preferredId : products[0]?.id;
  state.gas = selected ?? '';
  fillSelect(
    elements.product,
    products.map((product) => ({ value: product.id, label: product.model })),
    state.gas,
  );
}

function populateComparison() {
  const previous = elements.compare.value;
  const fragment = document.createDocumentFragment();
  const empty = document.createElement('option');
  empty.value = '';
  empty.textContent = 'Choisir une deuxième bouteille';
  fragment.append(empty);
  for (const { brand } of data.brands) {
    const group = document.createElement('optgroup');
    group.label = brand;
    for (const product of productsForBrand(data, brand)) {
      const option = document.createElement('option');
      option.value = product.id;
      option.textContent = `${product.model} (${product.labelPsi} PSI)`;
      group.append(option);
    }
    fragment.append(group);
  }
  elements.compare.replaceChildren(fragment);
  elements.compare.value = previous === state.gas ? '' : previous;
}

function formatOperatingRange(range) {
  if (!range || (range.min == null && range.max == null)) return 'aucune plage publiée';
  if (range.min != null && range.max != null) return `de ${range.min} à ${range.max} °C`;
  if (range.min != null) return `à partir de ${range.min} °C`;
  return `jusqu’à ${range.max} °C`;
}

function commercialPressureText(product) {
  if (product.labelPsi === product.referencePsi) return `${product.labelPsi} PSI`;
  return `${product.labelPsi} PSI (nom commercial ; ancre fabricant ${product.referencePsi} PSI)`;
}

function renderSources(product) {
  const sourceMap = new Map(data.sources.map((source) => [source.id, source]));
  elements.sources.replaceChildren();
  for (const sourceId of product.sourceIds) {
    const source = sourceMap.get(sourceId);
    if (!source) continue;
    const item = document.createElement('li');
    const link = document.createElement('a');
    link.href = source.url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.textContent = source.publisher;
    const detail = document.createElement('span');
    detail.textContent = ` — ${source.supports}`;
    item.append(link, detail);
    elements.sources.append(item);
  }
}

function renderNotes(product) {
  elements.notes.replaceChildren();
  for (const note of product.notesFr ?? []) {
    const item = document.createElement('li');
    item.textContent = note;
    elements.notes.append(item);
  }
  elements.notes.closest('[data-notes-block]').hidden = elements.notes.childElementCount === 0;
}

function setWarning(element, message) {
  element.textContent = message;
  element.hidden = !message;
}

function renderResult({ announce = true } = {}) {
  currentResult = resultForSelection(data, state);
  if (!currentResult) return;
  const { product, point, presentation, estimatedPsi, estimatedBar, temperatureC } = currentResult;

  elements.psi.textContent = numberFormat.format(estimatedPsi);
  elements.bar.textContent = preciseFormat.format(estimatedBar);
  elements.name.textContent = fullProductName(product);
  elements.commercial.textContent = commercialPressureText(product);
  elements.reference.textContent = `${product.referencePsi} PSI à ${product.referenceTemperatureC} °C`;
  elements.precise.textContent = `${preciseFormat.format(estimatedPsi)} PSI · ${preciseFormat.format(estimatedBar)} bar`;
  elements.kind.textContent = presentation.label;
  elements.kindPill.textContent = presentation.label;
  elements.kindPill.dataset.tone = presentation.tone;
  elements.collectionDate.textContent = dateFormat.format(new Date(`${data.generatedAt}T00:00:00Z`));

  setWarning(
    elements.rangeWarning,
    point.insidePublishedOperatingRange === false
      ? `Température hors de la plage d’utilisation publiée (${formatOperatingRange(product.operatingRangeC)}). Cette indication n’est pas une validation de sécurité.`
      : '',
  );
  setWarning(elements.extrapolationWarning, presentation.warning);
  renderSources(product);
  renderNotes(product);
  elements.result.hidden = false;
  if (announce) elements.status.textContent = `${fullProductName(product)} : ${numberFormat.format(estimatedPsi)} PSI à ${temperatureC} °C.`;
  renderComparison();
}

function renderComparison() {
  const gas = elements.compare.value;
  if (!gas || gas === state.gas) {
    elements.compareResult.hidden = true;
    elements.compareResult.textContent = '';
    return;
  }
  const compared = resultForSelection(data, { gas, temperatureC: state.temperatureC });
  if (!compared) return;
  const difference = compared.estimatedPsi - currentResult.estimatedPsi;
  const sign = difference > 0 ? '+' : '';
  elements.compareResult.textContent = `${fullProductName(compared.product)} : ${numberFormat.format(compared.estimatedPsi)} PSI (${preciseFormat.format(compared.estimatedBar)} bar), soit ${sign}${numberFormat.format(difference)} PSI par rapport au premier choix.`;
  elements.compareResult.hidden = false;
}

function syncTemperature(value, { commit = true } = {}) {
  const temperatureC = normalizeTemperature(value, state.temperatureC);
  state.temperatureC = temperatureC;
  elements.temperature.value = String(temperatureC);
  elements.temperatureRange.value = String(temperatureC);
  elements.temperatureOutput.textContent = `${temperatureC} °C`;
  if (commit) commitSelection();
}

function commitSelection() {
  saveSelection();
  updateUrl();
  renderResult();
}

function resultText() {
  if (!currentResult) return '';
  const { product, estimatedPsi, estimatedBar, temperatureC, presentation } = currentResult;
  return [
    `${fullProductName(product)} à ${temperatureC} °C`,
    `${numberFormat.format(estimatedPsi)} PSI (${preciseFormat.format(estimatedBar)} bar)`,
    `Pression commerciale : ${commercialPressureText(product)}`,
    `Type : ${presentation.label}`,
    REQUIRED_DISCLAIMER,
    location.href,
  ].join('\n');
}

async function copyText(text) {
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const area = document.createElement('textarea');
  area.value = text;
  area.setAttribute('readonly', '');
  area.style.position = 'fixed';
  area.style.opacity = '0';
  document.body.append(area);
  area.select();
  const copied = document.execCommand('copy');
  area.remove();
  if (!copied) throw new Error('Copie indisponible');
}

function showFeedback(message) {
  elements.feedback.textContent = message;
  window.setTimeout(() => {
    if (elements.feedback.textContent === message) elements.feedback.textContent = '';
  }, 4000);
}

async function handleCopy() {
  try {
    await copyText(resultText());
    showFeedback('Résultat copié.');
  } catch {
    showFeedback('La copie automatique est indisponible sur ce navigateur.');
  }
}

async function handleShare() {
  const product = currentResult?.product;
  if (!product) return;
  const shareData = {
    title: `Pression théorique — ${fullProductName(product)}`,
    text: resultText(),
    url: location.href,
  };
  if (navigator.share) {
    try {
      await navigator.share(shareData);
      showFeedback('Résultat partagé.');
    } catch (error) {
      if (error?.name !== 'AbortError') showFeedback('Partage annulé ou indisponible.');
    }
    return;
  }
  await handleCopy();
}

function bindEvents() {
  elements.form.addEventListener('submit', (event) => event.preventDefault());
  elements.temperatureRange.addEventListener('input', () => syncTemperature(elements.temperatureRange.value));
  elements.temperature.addEventListener('change', () => syncTemperature(elements.temperature.value));
  elements.temperature.addEventListener('input', () => {
    if (elements.temperature.value !== '') syncTemperature(elements.temperature.value);
  });
  elements.brand.addEventListener('change', () => {
    state.brand = elements.brand.value;
    populateProducts('');
    populateComparison();
    commitSelection();
  });
  elements.product.addEventListener('change', () => {
    state.gas = elements.product.value;
    populateComparison();
    commitSelection();
  });
  elements.compare.addEventListener('change', renderComparison);
  elements.copy.addEventListener('click', handleCopy);
  elements.share.addEventListener('click', handleShare);
}

async function initialize() {
  try {
    const response = await fetch(DATA_URL);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    data = await response.json();
    state = resolveSelection(data, location.search, readStoredSelection());
    populateBrands();
    populateProducts(state.gas);
    populateComparison();
    syncTemperature(state.temperatureC, { commit: false });
    bindEvents();
    saveSelection();
    updateUrl();
    renderResult({ announce: false });
    elements.status.textContent = `Outil chargé : ${data.products.length} bouteilles disponibles.`;
    document.documentElement.dataset.gasPressureReady = 'true';
  } catch (error) {
    elements.status.textContent = 'Impossible de charger les données de pression. Réessaie après une première visite en ligne.';
    elements.form.setAttribute('aria-disabled', 'true');
    for (const control of elements.form.elements) control.disabled = true;
    console.error('Chargement de l’outil gaz impossible', error);
  }
}

initialize();
