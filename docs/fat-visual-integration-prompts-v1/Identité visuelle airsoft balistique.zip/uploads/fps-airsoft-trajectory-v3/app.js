import {
  ATP,
  DEFAULT_SHOT,
  analyzeTrajectory,
  findFlatSpin,
  fpsToMps,
  holdoverTable,
  mpsToFps,
  normalizeShot,
  simulateTrajectory,
} from './physics-core.js';
import { buildChartValues, chartYDomain } from './chart-data.js';

const root = document.querySelector('[data-trajectory-app]');

if (root) {
  const fields = Object.fromEntries(
    [...root.querySelectorAll('[data-shot-field]')].map((element) => [element.dataset.shotField, element]),
  );
  const canvas = root.querySelector('#trajectory-chart');
  const chartCaption = root.querySelector('#chart-caption');
  const resultStatus = root.querySelector('#result-status');
  const compareButton = root.querySelector('#compare-shot');
  const resetButton = root.querySelector('#reset-shot');
  const shareButton = root.querySelector('#share-shot');
  const shareFeedback = root.querySelector('#share-feedback');
  const rpmOutput = root.querySelector('#rpm-output');
  const spinSetting = root.querySelector('#spin-setting');
  const spinAdjustment = root.querySelector('#spin-adjustment');
  const spinAutoButton = root.querySelector('#spin-auto');
  const comparisonList = root.querySelector('#comparison-list');
  const tableBody = root.querySelector('#holdover-body');
  const metricElements = Object.fromEntries(
    [...root.querySelectorAll('[data-metric]')].map((element) => [element.dataset.metric, element]),
  );

  const colors = ['#a7ff3f', '#35d9ff', '#ffb547', '#d59bff'];
  const state = {
    worker: null,
    requestId: 0,
    latestResult: null,
    comparisons: [],
    chartMode: 'trajectory',
    energyWasLastEdited: true,
    resizeFrame: null,
    flatSpinRpm: null,
    flatSpinRangeM: null,
    spinOffsetRpm: 0,
  };
  const SPIN_STEP_RPM = 250;

  const format = (value, digits = 1) => Number.isFinite(value)
    ? new Intl.NumberFormat('fr-FR', { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(value)
    : '—';

  function setField(name, value, digits = null) {
    if (!fields[name]) return;
    fields[name].value = digits == null ? value : Number(value).toFixed(digits);
  }

  function applyDefaults() {
    const saved = (() => {
      try { return JSON.parse(localStorage.getItem('fat-shot-v3') || '{}'); } catch { return {}; }
    })();
    const query = new URLSearchParams(location.search);
    const aliases = {
      massG: 'm', energyJ: 'j', initialRpm: 'rpm', zeroDistanceM: 'z',
      windSpeedKmh: 'w', windAngleDeg: 'wd', temperatureC: 't',
      pressureHpa: 'p', angleDeg: 'a', cantDeg: 'c',
    };
    const values = { ...DEFAULT_SHOT, ...saved };
    if (saved.initialRpm == null && saved.hopPercent != null) {
      values.initialRpm = normalizeShot({ ...values, initialRpm: undefined }).initialRpm;
    }
    for (const [name, alias] of Object.entries(aliases)) {
      if (query.has(alias)) values[name] = Number(query.get(alias));
    }
    if (!query.has('rpm') && query.has('h')) {
      values.initialRpm = normalizeShot({
        ...values,
        initialRpm: undefined,
        hopPercent: Number(query.get('h')),
      }).initialRpm;
    }
    for (const [name, element] of Object.entries(fields)) {
      if (values[name] != null) element.value = values[name];
    }
    syncVelocityFromEnergy();
    return {
      preserveCurrentSpin: query.has('rpm') || query.has('h'),
      savedSpinOffsetRpm: Number(saved._spinOffsetRpm) || 0,
    };
  }

  function syncVelocityFromEnergy() {
    const massKg = Math.max(Number(fields.massG?.value) || DEFAULT_SHOT.massG, 0.01) / 1000;
    const energy = Math.max(Number(fields.energyJ?.value) || 0, 0);
    const mps = Math.sqrt(2 * energy / massKg);
    setField('velocityFps', mpsToFps(mps), 0);
    setField('velocityMps', mps, 1);
  }

  function syncEnergyFromVelocity() {
    const massKg = Math.max(Number(fields.massG?.value) || DEFAULT_SHOT.massG, 0.01) / 1000;
    const fps = Math.max(Number(fields.velocityFps?.value) || 0, 0);
    const mps = fpsToMps(fps);
    setField('velocityMps', mps, 1);
    setField('energyJ', 0.5 * massKg * mps ** 2, 2);
  }

  function readShot() {
    const input = {};
    for (const [name, element] of Object.entries(fields)) {
      if (name === 'velocityFps' || name === 'velocityMps') continue;
      input[name] = Number(element.value);
    }
    return normalizeShot(input);
  }

  function persistShot(shot) {
    const allowed = [
      'massG', 'energyJ', 'initialRpm', 'zeroDistanceM', 'windSpeedKmh',
      'windAngleDeg', 'temperatureC', 'pressureHpa', 'angleDeg', 'cantDeg',
      'shootingHeightM', 'scopeHeightM', 'latitudeDeg', 'diameterMm',
    ];
    const stored = Object.fromEntries(allowed.map((key) => [key, shot[key]]));
    stored._spinOffsetRpm = state.spinOffsetRpm;
    try { localStorage.setItem('fat-shot-v3', JSON.stringify(stored)); } catch { /* stockage facultatif */ }
  }

  function updateSpinReadout() {
    const shot = readShot();
    const offsetRpm = state.flatSpinRpm == null ? 0 : shot.initialRpm - state.flatSpinRpm;
    state.spinOffsetRpm = offsetRpm;
    if (spinSetting) spinSetting.textContent = 'HOP UP AUTO';
    if (spinAdjustment) {
      spinAdjustment.textContent = offsetRpm === 0
        ? 'tir tendu conseillé'
        : `correction ${offsetRpm > 0 ? '+' : '−'}${format(Math.abs(offsetRpm), 0)} tr/min`;
    }
    if (rpmOutput) {
      const spinRegime = shot.initialSpinRatio > 0
        && shot.initialSpinRatio < ATP.reverseMagnusLimit
        ? ' · Reverse Magnus au départ'
        : '';
      const flatRange = Number.isFinite(state.flatSpinRangeM)
        ? ` · tendu ≈ ${format(state.flatSpinRangeM, 0)} m`
        : '';
      rpmOutput.textContent = `${format(shot.initialRpm, 0)} tr/min · V/U ${format(shot.initialSpinRatio, 3)}${flatRange}${spinRegime}`;
    }
  }

  function recalculateFlatSpin({ preserveCurrent = false, offsetRpm = 0 } = {}) {
    const currentRpm = Number(fields.initialRpm?.value) || 0;
    const recommendation = findFlatSpin(readShot(), { incrementRpm: SPIN_STEP_RPM });
    state.flatSpinRpm = recommendation.initialRpm;
    state.flatSpinRangeM = recommendation.flatRangeM;
    const selectedRpm = preserveCurrent
      ? currentRpm
      : Math.max(0, recommendation.initialRpm + offsetRpm);
    setField('initialRpm', selectedRpm);
    state.spinOffsetRpm = selectedRpm - recommendation.initialRpm;
    updateSpinReadout();
  }

  function scheduleFlatSpin() {
    clearTimeout(scheduleFlatSpin.timer);
    clearTimeout(scheduleSimulation.timer);
    resultStatus.textContent = 'Recherche du hop-up tendu…';
    root.classList.add('is-calculating');
    scheduleFlatSpin.timer = setTimeout(() => {
      recalculateFlatSpin();
      scheduleSimulation();
    }, 160);
  }

  function scheduleSimulation() {
    clearTimeout(scheduleSimulation.timer);
    scheduleSimulation.timer = setTimeout(runSimulation, 120);
    updateSpinReadout();
  }

  async function runSimulation() {
    const shot = readShot();
    persistShot(shot);
    const requestId = ++state.requestId;
    resultStatus.textContent = 'Calcul ATP en cours…';
    root.classList.add('is-calculating');

    if (state.worker) {
      state.worker.postMessage({ type: 'simulate', requestId, shot });
      return;
    }

    await new Promise((resolve) => setTimeout(resolve, 0));
    const simulation = simulateTrajectory(shot);
    receiveResult({
      ok: true,
      requestId,
      simulation,
      metrics: analyzeTrajectory(simulation),
      holdover: holdoverTable(simulation),
    });
  }

  function receiveResult(message) {
    if (message.requestId !== state.requestId) return;
    root.classList.remove('is-calculating');
    if (!message.ok) {
      resultStatus.textContent = `Calcul interrompu : ${message.error}`;
      return;
    }
    state.latestResult = message;
    renderResults();
  }

  function valueAt(metrics, key, suffix, digits = 1) {
    const value = metrics[key];
    return Number.isFinite(value) ? `${format(value, digits)}${suffix}` : 'Hors portée';
  }

  function renderResults() {
    const { metrics, simulation, holdover } = state.latestResult;
    const { config } = simulation;
    metricElements.muzzleEnergy.textContent = valueAt({ value: config.energyJ }, 'value', ' J', 2);
    metricElements.usefulRange.textContent = valueAt(metrics, 'usefulRangeM', ' m', 0);
    metricElements.maximumRange.textContent = valueAt(metrics, 'maximumRangeM', ' m', 0);
    metricElements.time50.textContent = valueAt(metrics, 'time50S', ' s', 2);
    metricElements.energy50.textContent = valueAt(metrics, 'energy50J', ' J', 2);
    metricElements.drift50.textContent = valueAt(
      { drift: metrics.drift50M == null ? null : metrics.drift50M * 100 },
      'drift', ' cm', 1,
    );
    metricElements.rpm.textContent = `${format(config.initialRpm, 0)} tr/min`;
    metricElements.cannonAngle.textContent = `${format(config.angleDeg, 2)}°`;
    const zeroStatus = metrics.sight.zeroResolved
      ? `zéro optique ${format(config.zeroDistanceM, 0)} m`
      : `zéro optique ${format(config.zeroDistanceM, 0)} m hors portée`;
    resultStatus.textContent = `Modèle ATP · ${zeroStatus} · ${format(simulation.atmosphere.densityKgM3, 3)} kg/m³ · pas ${format(config.dt * 1000, 1)} ms`;

    tableBody.innerHTML = holdover.map((row) => `
      <tr>
        <th scope="row">${format(row.distanceM, 0)} m</th>
        <td class="${row.deviationCm >= 0 ? 'positive' : 'negative'}">${row.deviationCm >= 0 ? '+' : ''}${format(row.deviationCm, 1)} cm</td>
        <td>${format(row.correctionMrad, 1)} mrad</td>
        <td>${format(row.energyJ, 2)} J</td>
        <td>${format(row.timeS, 2)} s</td>
        <td>${row.driftCm >= 0 ? '+' : ''}${format(row.driftCm, 1)} cm</td>
      </tr>
    `).join('');
    drawChart();
  }

  function getSeries(result, color, label) {
    const chart = buildChartValues(result.simulation, state.chartMode);
    return {
      ...chart,
      color,
      label,
    };
  }

  function drawChart() {
    if (!canvas || !state.latestResult) return;
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(300, rect.width);
    const height = Math.max(220, rect.height);
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    const context = canvas.getContext('2d');
    context.scale(dpr, dpr);
    context.clearRect(0, 0, width, height);

    const current = getSeries(
      state.latestResult,
      colors[0],
      `${format(state.latestResult.simulation.config.massG, 2)} g · ${format(state.latestResult.simulation.config.energyJ, 2)} J`,
    );
    const series = [current, ...state.comparisons.map((item, index) => getSeries(item.result, colors[index + 1], item.label))];
    const all = series.flatMap((item) => item.values);
    const maxX = Math.max(10, ...all.map((point) => point.x));
    const { minY, maxY } = chartYDomain(series);

    const margin = { top: 28, right: 18, bottom: 46, left: width < 520 ? 46 : 62 };
    const plotWidth = width - margin.left - margin.right;
    const plotHeight = height - margin.top - margin.bottom;
    const mapX = (value) => margin.left + value / maxX * plotWidth;
    const mapY = (value) => margin.top + (maxY - value) / (maxY - minY) * plotHeight;

    context.font = '12px Inter, system-ui, sans-serif';
    context.lineWidth = 1;
    context.strokeStyle = 'rgba(255,255,255,.12)';
    context.fillStyle = '#9eaaae';
    context.textAlign = 'right';
    context.textBaseline = 'middle';
    for (let step = 0; step <= 5; step += 1) {
      const value = minY + (maxY - minY) * step / 5;
      const y = mapY(value);
      context.beginPath(); context.moveTo(margin.left, y); context.lineTo(width - margin.right, y); context.stroke();
      context.fillText(format(value, Math.abs(maxY - minY) > 100 ? 0 : 1), margin.left - 8, y);
    }
    context.textAlign = 'center';
    context.textBaseline = 'top';
    for (let step = 0; step <= 5; step += 1) {
      const value = maxX * step / 5;
      const x = mapX(value);
      context.beginPath(); context.moveTo(x, margin.top); context.lineTo(x, height - margin.bottom); context.stroke();
      context.fillText(`${format(value, 0)} m`, x, height - margin.bottom + 10);
    }
    if (current.showZeroLine && minY <= 0 && maxY >= 0) {
      context.strokeStyle = 'rgba(255,255,255,.5)';
      context.setLineDash([5, 5]);
      context.beginPath(); context.moveTo(margin.left, mapY(0)); context.lineTo(width - margin.right, mapY(0)); context.stroke();
      context.setLineDash([]);
    }

    for (const item of series) {
      context.beginPath();
      item.values.forEach((point, index) => {
        const x = mapX(point.x);
        const y = mapY(point.y);
        if (index === 0) context.moveTo(x, y); else context.lineTo(x, y);
      });
      context.strokeStyle = item.color;
      context.lineWidth = 2.5;
      context.stroke();
    }

    chartCaption.textContent = `${current.axisLabel} (${current.unit}) selon la distance.${current.referenceLabel ? ` ${current.referenceLabel}` : ''}`;
    canvas.setAttribute('aria-label', chartCaption.textContent);
    renderComparisonList(series);
  }

  function renderComparisonList(series) {
    comparisonList.innerHTML = series.map((item, index) => `
      <li>
        <span class="legend-swatch" style="--legend:${item.color}"></span>
        <span>${item.label}</span>
        ${index === 0 ? '<small>Actuel</small>' : `<button type="button" data-remove-comparison="${index - 1}" aria-label="Retirer ${item.label}">×</button>`}
      </li>
    `).join('');
  }

  function addComparison() {
    if (!state.latestResult) return;
    const { config } = state.latestResult.simulation;
    if (state.comparisons.length >= 3) state.comparisons.shift();
    state.comparisons.push({
      label: `${format(config.massG, 2)} g · ${format(config.energyJ, 2)} J · ${format(config.initialRpm, 0)} tr/min`,
      result: structuredClone(state.latestResult),
    });
    drawChart();
  }

  async function shareShot() {
    const shot = readShot();
    const query = new URLSearchParams({
      m: shot.massG, j: shot.energyJ.toFixed(2), rpm: shot.initialRpm,
      z: shot.zeroDistanceM, w: shot.windSpeedKmh, wd: shot.windAngleDeg,
      t: shot.temperatureC, p: shot.pressureHpa, a: shot.angleDeg, c: shot.cantDeg,
    });
    const url = `${location.origin}${location.pathname}?${query}`;
    try {
      if (navigator.share) {
        await navigator.share({ title: 'Mon setup F.A.T.', text: 'Passe mon setup airsoft au banc balistique.', url });
      } else {
        await navigator.clipboard.writeText(url);
        shareFeedback.textContent = 'Lien copié. À envoyer au squad, ou à ton mécano préféré.';
      }
    } catch (error) {
      if (error?.name !== 'AbortError') shareFeedback.textContent = `Lien : ${url}`;
    }
  }

  const flatSpinInputs = new Set([
    'massG', 'energyJ', 'velocityFps', 'temperatureC', 'pressureHpa', 'diameterMm',
  ]);

  for (const [name, element] of Object.entries(fields)) {
    element.addEventListener('input', () => {
      if (name === 'energyJ') {
        state.energyWasLastEdited = true;
        syncVelocityFromEnergy();
      } else if (name === 'velocityFps') {
        state.energyWasLastEdited = false;
        syncEnergyFromVelocity();
      } else if (name === 'massG') {
        if (state.energyWasLastEdited) syncVelocityFromEnergy(); else syncEnergyFromVelocity();
      }
      if (flatSpinInputs.has(name)) scheduleFlatSpin();
      else scheduleSimulation();
    });
  }

  root.querySelectorAll('[data-shot-preset]').forEach((button) => {
    button.addEventListener('click', () => {
      const preset = JSON.parse(button.dataset.shotPreset);
      for (const [name, value] of Object.entries(preset)) setField(name, value);
      state.energyWasLastEdited = true;
      syncVelocityFromEnergy();
      if (Object.hasOwn(preset, 'initialRpm')) {
        recalculateFlatSpin({ preserveCurrent: true });
        scheduleSimulation();
      } else {
        scheduleFlatSpin();
      }
    });
  });

  root.querySelectorAll('[data-spin-delta]').forEach((button) => {
    button.addEventListener('click', () => {
      const deltaRpm = Number(button.dataset.spinDelta) || 0;
      const currentRpm = Number(fields.initialRpm?.value) || state.flatSpinRpm || 0;
      setField('initialRpm', Math.max(0, currentRpm + deltaRpm));
      updateSpinReadout();
      scheduleSimulation();
    });
  });

  spinAutoButton?.addEventListener('click', () => {
    if (state.flatSpinRpm == null) recalculateFlatSpin();
    else setField('initialRpm', state.flatSpinRpm);
    state.spinOffsetRpm = 0;
    updateSpinReadout();
    scheduleSimulation();
  });

  root.querySelectorAll('[data-chart-mode]').forEach((button) => {
    button.addEventListener('click', () => {
      state.chartMode = button.dataset.chartMode;
      root.querySelectorAll('[data-chart-mode]').forEach((item) => item.setAttribute('aria-selected', String(item === button)));
      drawChart();
    });
  });

  comparisonList.addEventListener('click', (event) => {
    const button = event.target.closest('[data-remove-comparison]');
    if (!button) return;
    state.comparisons.splice(Number(button.dataset.removeComparison), 1);
    drawChart();
  });

  compareButton.addEventListener('click', addComparison);
  shareButton.addEventListener('click', shareShot);
  resetButton.addEventListener('click', () => {
    localStorage.removeItem('fat-shot-v3');
    for (const [name, element] of Object.entries(fields)) {
      if (DEFAULT_SHOT[name] != null) element.value = DEFAULT_SHOT[name];
    }
    state.comparisons = [];
    state.energyWasLastEdited = true;
    syncVelocityFromEnergy();
    recalculateFlatSpin();
    scheduleSimulation();
  });

  window.addEventListener('resize', () => {
    cancelAnimationFrame(state.resizeFrame);
    state.resizeFrame = requestAnimationFrame(drawChart);
  });

  try {
    state.worker = new Worker('./trajectory.worker.js', { type: 'module' });
    state.worker.addEventListener('message', (event) => receiveResult(event.data));
    state.worker.addEventListener('error', () => { state.worker = null; });
  } catch {
    state.worker = null;
  }

  const defaults = applyDefaults();
  recalculateFlatSpin({
    preserveCurrent: defaults.preserveCurrentSpin,
    offsetRpm: defaults.preserveCurrentSpin ? 0 : defaults.savedSpinOffsetRpm,
  });
  runSimulation();
}
