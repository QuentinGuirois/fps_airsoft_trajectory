export const PSI_PER_BAR = 14.5037738;
export const MIN_TEMPERATURE_C = -15;
export const MAX_TEMPERATURE_C = 40;

const POINT_PRESENTATIONS = Object.freeze({
  manufacturer_test_point: {
    label: 'valeur publiée',
    tone: 'published',
    warning: '',
  },
  manufacturer_or_distributor_anchor: {
    label: 'valeur publiée',
    tone: 'published',
    warning: '',
  },
  interpolated_manufacturer_grid: {
    label: 'interpolation entre mesures publiées',
    tone: 'interpolated',
    warning: '',
  },
  estimated_propane_ratio: {
    label: 'estimation depuis la valeur fabricant',
    tone: 'estimated',
    warning: '',
  },
  extrapolated_propane_ratio: {
    label: 'extrapolation hors des mesures publiées',
    tone: 'extrapolated',
    warning: 'Cette valeur est extrapolée au-delà des mesures publiées : son incertitude est renforcée.',
  },
});

export function psiToBar(psi) {
  const value = Number(psi);
  return Number.isFinite(value) ? value / PSI_PER_BAR : Number.NaN;
}

export function normalizeTemperature(value, fallback = 20) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return normalizeTemperature(fallback, 20);
  return Math.min(MAX_TEMPERATURE_C, Math.max(MIN_TEMPERATURE_C, Math.round(parsed)));
}

export function productsForBrand(data, brand) {
  if (!data?.products || typeof brand !== 'string') return [];
  return data.products.filter((product) => product.brand === brand);
}

export function productById(data, id) {
  return data?.products?.find((product) => product.id === id) ?? null;
}

export function pointForTemperature(product, temperatureC) {
  const temperature = normalizeTemperature(temperatureC);
  return product?.curve?.find((point) => point.temperatureC === temperature) ?? null;
}

export function pointPresentation(status) {
  return POINT_PRESENTATIONS[status] ?? {
    label: 'estimation documentée',
    tone: 'estimated',
    warning: '',
  };
}

export function fullProductName(product) {
  return product ? `${product.brand} — ${product.model}` : '';
}

export function resolveSelection(data, search = '', storedSelection = {}) {
  const params = search instanceof URLSearchParams
    ? search
    : new URLSearchParams(String(search).replace(/^\?/, ''));
  const products = data?.products ?? [];
  const brands = data?.brands?.map((entry) => entry.brand) ?? [...new Set(products.map((product) => product.brand))];
  const fallbackProduct = products[0] ?? null;

  const urlProduct = params.has('gas') ? productById(data, params.get('gas')) : null;
  const urlBrand = params.has('brand') && brands.includes(params.get('brand')) ? params.get('brand') : null;
  const storedProduct = productById(data, storedSelection?.gas);
  const storedBrand = brands.includes(storedSelection?.brand) ? storedSelection.brand : null;

  let product = urlProduct;
  let brand = urlProduct?.brand ?? urlBrand;

  if (!product && brand) product = productsForBrand(data, brand)[0] ?? null;
  if (!product && !params.has('brand') && !params.has('gas')) {
    product = storedProduct ?? (storedBrand ? productsForBrand(data, storedBrand)[0] : null);
    brand = product?.brand ?? storedBrand;
  }
  product ??= fallbackProduct;
  brand = product?.brand ?? brand ?? brands[0] ?? '';

  const storedTemperature = normalizeTemperature(storedSelection?.t, 20);
  const temperatureC = params.has('t')
    ? normalizeTemperature(params.get('t'), storedTemperature)
    : storedTemperature;

  return {
    temperatureC,
    brand,
    gas: product?.id ?? '',
  };
}

export function selectionSearchParams(selection) {
  const params = new URLSearchParams();
  params.set('t', String(normalizeTemperature(selection?.temperatureC)));
  if (selection?.brand) params.set('brand', selection.brand);
  if (selection?.gas) params.set('gas', selection.gas);
  return params;
}

export function resultForSelection(data, selection) {
  const product = productById(data, selection?.gas);
  if (!product) return null;
  const temperatureC = normalizeTemperature(selection?.temperatureC);
  const point = pointForTemperature(product, temperatureC);
  if (!point) return null;
  return {
    product,
    point,
    temperatureC,
    estimatedPsi: point.estimatedPsi,
    estimatedBar: psiToBar(point.estimatedPsi),
    presentation: pointPresentation(point.pointStatus),
  };
}
