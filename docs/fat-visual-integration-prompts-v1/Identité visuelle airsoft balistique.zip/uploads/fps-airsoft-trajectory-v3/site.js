const menuButton = document.querySelector('[data-menu-button]');
const menu = document.querySelector('[data-menu]');
const gasToolPath = '/outils/choisir-gaz-airsoft-pression-temperature/';

if (menu && !menu.querySelector(`a[href="${gasToolPath}"]`)) {
  const gasToolLink = document.createElement('a');
  gasToolLink.href = gasToolPath;
  gasToolLink.textContent = 'Gaz / température';
  if (location.pathname === gasToolPath) gasToolLink.setAttribute('aria-current', 'page');
  const converterLink = menu.querySelector('a[href="/convertisseur-joules-fps/"]');
  if (converterLink) converterLink.after(gasToolLink);
  else menu.append(gasToolLink);
}

if (menuButton && menu) {
  menuButton.addEventListener('click', () => {
    const open = menuButton.getAttribute('aria-expanded') === 'true';
    menuButton.setAttribute('aria-expanded', String(!open));
    menu.toggleAttribute('data-open', !open);
  });
}

let installPrompt = null;
const installButtons = [...document.querySelectorAll('[data-install-app]')];

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  installPrompt = event;
  installButtons.forEach((button) => { button.hidden = false; });
});

installButtons.forEach((button) => {
  button.addEventListener('click', async () => {
    if (!installPrompt) {
      document.querySelector('[data-install-help]')?.removeAttribute('hidden');
      return;
    }
    installPrompt.prompt();
    await installPrompt.userChoice;
    installPrompt = null;
    installButtons.forEach((item) => { item.hidden = true; });
  });
});

document.querySelectorAll('[data-converter]').forEach((converter) => {
  const mass = converter.querySelector('[data-convert-mass]');
  const energy = converter.querySelector('[data-convert-energy]');
  const fps = converter.querySelector('[data-convert-fps]');
  const mps = converter.querySelector('[data-convert-mps]');
  let source = 'energy';

  const updateFromEnergy = () => {
    const massKg = Math.max(Number(mass.value), 0.01) / 1000;
    const velocity = Math.sqrt(2 * Math.max(Number(energy.value), 0) / massKg);
    fps.value = Math.round(velocity / 0.3048);
    mps.value = velocity.toFixed(1);
  };
  const updateFromFps = () => {
    const massKg = Math.max(Number(mass.value), 0.01) / 1000;
    const velocity = Math.max(Number(fps.value), 0) * 0.3048;
    energy.value = (0.5 * massKg * velocity ** 2).toFixed(2);
    mps.value = velocity.toFixed(1);
  };

  energy.addEventListener('input', () => { source = 'energy'; updateFromEnergy(); });
  fps.addEventListener('input', () => { source = 'fps'; updateFromFps(); });
  mass.addEventListener('input', () => { if (source === 'energy') updateFromEnergy(); else updateFromFps(); });
  updateFromEnergy();
});

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/service-worker.js'));
}
